"""Application rules for inventory, borrowers, checkout and returns."""
import sqlite3
from datetime import date
from models import Equipment, Borrower
from validators import required_fields, valid_code, validate_loan_dates, validate_return_date

class CampusHubService:
    def __init__(self, database):
        self.db = database

    def add_equipment(self, values):
        ok, message = required_fields({
            "Asset code": values.get("asset_code"), "Name": values.get("name"),
            "Category": values.get("category"), "Location": values.get("location")})
        if not ok:
            raise ValueError(message)
        if not valid_code(values["asset_code"]):
            raise ValueError("Asset code must contain 1–30 characters.")
        item = Equipment(*(values[k].strip() for k in
                           ("asset_code","name","category","location")),
                         values.get("condition","Good"), "Available")
        try:
            self.db.add_equipment(item)
        except sqlite3.IntegrityError:
            raise ValueError("That asset code already exists.")

    def update_equipment(self, asset_id, values, current_status):
        ok, message = required_fields({k: values.get(k) for k in
            ("name","category","location","condition","status")})
        if not ok:
            raise ValueError(message)
        status = values["status"]
        if current_status == "Borrowed" and status != "Borrowed":
            raise ValueError("A borrowed asset's status can only change after its loan is returned.")
        if current_status == "Inactive":
            raise ValueError("Inactive assets cannot be edited.")
        item = Equipment("", values["name"].strip(), values["category"].strip(),
                         values["location"].strip(), values["condition"].strip(), status)
        self.db.update_equipment(asset_id, item)

    def add_borrower(self, values):
        ok, message = required_fields({k: values.get(k) for k in
            ("borrower_code","display_name","department_or_program")})
        if not ok:
            raise ValueError(message)
        if not valid_code(values["borrower_code"]):
            raise ValueError("Borrower code must contain 1–30 characters.")
        try:
            self.db.add_borrower(Borrower(*(values[k].strip() for k in
                ("borrower_code","display_name","department_or_program"))))
        except sqlite3.IntegrityError:
            raise ValueError("That borrower code already exists.")

    def checkout(self, asset_code, borrower_code, borrowed_on, due_on):
        ok, message = validate_loan_dates(borrowed_on, due_on)
        if not ok:
            raise ValueError(message)
        asset = self.db.get_equipment(asset_code)
        borrower = self.db.get_borrower(borrower_code)
        if asset is None:
            raise ValueError("Asset code was not found.")
        if borrower is None:
            raise ValueError("Borrower code was not found.")
        if asset["status"] != "Available":
            raise ValueError("This equipment is not available for checkout.")
        if not borrower["active"]:
            raise ValueError("This borrower is inactive.")
        self.db.create_loan(asset["asset_id"], borrower["borrower_id"],
                            borrowed_on, due_on)

    def return_item(self, loan_id, returned_on):
        loan = self.db.get_loan(loan_id)
        if loan is None:
            raise ValueError("Loan ID was not found.")
        if loan["status"] != "Active":
            raise ValueError("This loan has already been returned.")
        ok, message = validate_return_date(returned_on, loan["borrowed_on"])
        if not ok:
            raise ValueError(message)
        self.db.return_loan(loan_id, returned_on)

    def dispatch(self, action):
        """Real match-case dispatcher used by the GUI."""
        match action:
            case "inventory":
                return self.db.list_equipment()
            case "borrowers":
                return self.db.list_borrowers()
            case "active":
                return self.db.list_loans("active")
            case "overdue":
                return self.db.list_loans("overdue")
            case _:
                return []
