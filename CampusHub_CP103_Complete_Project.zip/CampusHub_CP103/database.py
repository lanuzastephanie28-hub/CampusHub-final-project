"""SQLite persistence layer for CampusHub."""
from pathlib import Path
import sqlite3
from contextlib import contextmanager

DB_PATH = Path(__file__).resolve().parent / "data" / "campushub.db"

class Database:
    def __init__(self, db_path=DB_PATH):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    @contextmanager
    def connect(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        try:
            yield conn
        finally:
            conn.close()

    def initialize(self):
        with self.connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS equipment (
                    asset_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    asset_code TEXT NOT NULL UNIQUE COLLATE NOCASE,
                    name TEXT NOT NULL,
                    category TEXT NOT NULL,
                    location TEXT NOT NULL,
                    condition TEXT NOT NULL DEFAULT 'Good',
                    status TEXT NOT NULL DEFAULT 'Available'
                      CHECK(status IN ('Available','Borrowed','Under Maintenance','Inactive'))
                );
                CREATE TABLE IF NOT EXISTS borrowers (
                    borrower_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    borrower_code TEXT NOT NULL UNIQUE COLLATE NOCASE,
                    display_name TEXT NOT NULL,
                    department_or_program TEXT NOT NULL,
                    active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1))
                );
                CREATE TABLE IF NOT EXISTS loans (
                    loan_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    asset_id INTEGER NOT NULL,
                    borrower_id INTEGER NOT NULL,
                    borrowed_on TEXT NOT NULL,
                    due_on TEXT NOT NULL,
                    returned_on TEXT,
                    status TEXT NOT NULL DEFAULT 'Active'
                      CHECK(status IN ('Active','Returned')),
                    FOREIGN KEY(asset_id) REFERENCES equipment(asset_id),
                    FOREIGN KEY(borrower_id) REFERENCES borrowers(borrower_id)
                );
                CREATE INDEX IF NOT EXISTS idx_loans_status ON loans(status);
                CREATE INDEX IF NOT EXISTS idx_equipment_code ON equipment(asset_code);
            """)

    def add_equipment(self, item):
        with self.connect() as conn:
            conn.execute("""INSERT INTO equipment
                (asset_code,name,category,location,condition,status)
                VALUES (?,?,?,?,?,?)""",
                (item.asset_code, item.name, item.category, item.location,
                 item.condition, item.status))

    def update_equipment(self, asset_id, item):
        with self.connect() as conn:
            conn.execute("""UPDATE equipment SET name=?, category=?, location=?,
                condition=?, status=? WHERE asset_id=?""",
                (item.name, item.category, item.location, item.condition,
                 item.status, asset_id))

    def deactivate_equipment(self, asset_id):
        with self.connect() as conn:
            active = conn.execute(
                "SELECT COUNT(*) FROM loans WHERE asset_id=? AND status='Active'",
                (asset_id,)).fetchone()[0]
            if active:
                raise ValueError("This asset has an active loan and cannot be deactivated.")
            conn.execute("UPDATE equipment SET status='Inactive' WHERE asset_id=?", (asset_id,))

    def list_equipment(self, search=""):
        with self.connect() as conn:
            term = f"%{search.strip()}%"
            return conn.execute("""SELECT * FROM equipment
                WHERE asset_code LIKE ? OR name LIKE ? OR category LIKE ?
                ORDER BY asset_code""", (term, term, term)).fetchall()

    def get_equipment(self, asset_code):
        with self.connect() as conn:
            return conn.execute("SELECT * FROM equipment WHERE asset_code=?",
                                (asset_code.strip(),)).fetchone()

    def add_borrower(self, borrower):
        with self.connect() as conn:
            conn.execute("""INSERT INTO borrowers
                (borrower_code,display_name,department_or_program,active)
                VALUES (?,?,?,?)""",
                (borrower.borrower_code, borrower.display_name,
                 borrower.department_or_program, int(borrower.active)))

    def list_borrowers(self, search=""):
        with self.connect() as conn:
            term = f"%{search.strip()}%"
            return conn.execute("""SELECT * FROM borrowers
                WHERE borrower_code LIKE ? OR display_name LIKE ?
                   OR department_or_program LIKE ?
                ORDER BY borrower_code""", (term, term, term)).fetchall()

    def get_borrower(self, borrower_code):
        with self.connect() as conn:
            return conn.execute("SELECT * FROM borrowers WHERE borrower_code=?",
                                (borrower_code.strip(),)).fetchone()

    def create_loan(self, asset_id, borrower_id, borrowed_on, due_on):
        with self.connect() as conn:
            # Re-check status inside the transaction to prevent double checkout.
            asset = conn.execute("SELECT status FROM equipment WHERE asset_id=?",
                                 (asset_id,)).fetchone()
            borrower = conn.execute("SELECT active FROM borrowers WHERE borrower_id=?",
                                    (borrower_id,)).fetchone()
            if asset is None or asset["status"] != "Available":
                raise ValueError("The selected equipment is not available.")
            if borrower is None or not borrower["active"]:
                raise ValueError("The selected borrower is not active.")
            conn.execute("""INSERT INTO loans
                (asset_id,borrower_id,borrowed_on,due_on,status)
                VALUES (?,?,?,?, 'Active')""",
                (asset_id, borrower_id, borrowed_on, due_on))
            conn.execute("UPDATE equipment SET status='Borrowed' WHERE asset_id=?",
                         (asset_id,))

    def list_loans(self, view="all", search=""):
        with self.connect() as conn:
            today = __import__("datetime").date.today().isoformat()
            sql = """SELECT l.loan_id,e.asset_code,e.name AS asset_name,
                b.borrower_code,b.display_name AS borrower_name,
                l.borrowed_on,l.due_on,l.returned_on,l.status,
                CASE WHEN l.status='Active' AND l.due_on < ? THEN 'Overdue'
                     WHEN l.status='Active' THEN 'Active'
                     ELSE 'Returned' END AS display_status
                FROM loans l JOIN equipment e ON e.asset_id=l.asset_id
                JOIN borrowers b ON b.borrower_id=l.borrower_id"""
            params = [today]
            if view == "active":
                sql += " WHERE l.status='Active'"
            elif view == "overdue":
                sql += " WHERE l.status='Active' AND l.due_on < ?"
                params.append(today)
            elif view == "returned":
                sql += " WHERE l.status='Returned'"
            if search.strip():
                clause = (" AND " if " WHERE " in sql else " WHERE ")
                sql += clause + "(e.asset_code LIKE ? OR e.name LIKE ? OR b.borrower_code LIKE ? OR b.display_name LIKE ?)"
                term = f"%{search.strip()}%"
                params.extend([term, term, term, term])
            sql += " ORDER BY l.loan_id DESC"
            return conn.execute(sql, params).fetchall()

    def get_loan(self, loan_id):
        with self.connect() as conn:
            return conn.execute("""SELECT l.*,e.asset_code,e.name AS asset_name
                FROM loans l JOIN equipment e ON e.asset_id=l.asset_id
                WHERE l.loan_id=?""", (loan_id,)).fetchone()

    def return_loan(self, loan_id, returned_on):
        with self.connect() as conn:
            loan = conn.execute("SELECT asset_id,status FROM loans WHERE loan_id=?",
                                (loan_id,)).fetchone()
            if loan is None or loan["status"] != "Active":
                raise ValueError("The loan does not exist or has already been returned.")
            conn.execute("""UPDATE loans SET returned_on=?, status='Returned'
                WHERE loan_id=?""", (returned_on, loan_id))
            conn.execute("UPDATE equipment SET status='Available' WHERE asset_id=?",
                         (loan["asset_id"],))

    def dashboard_counts(self):
        with self.connect() as conn:
            today = __import__("datetime").date.today().isoformat()
            total = conn.execute("SELECT COUNT(*) FROM equipment WHERE status!='Inactive'").fetchone()[0]
            available = conn.execute("SELECT COUNT(*) FROM equipment WHERE status='Available'").fetchone()[0]
            active = conn.execute("SELECT COUNT(*) FROM loans WHERE status='Active'").fetchone()[0]
            overdue = conn.execute("SELECT COUNT(*) FROM loans WHERE status='Active' AND due_on < ?",
                                   (today,)).fetchone()[0]
            return {"total_assets": total, "available_assets": available,
                    "active_loans": active, "overdue_loans": overdue}
