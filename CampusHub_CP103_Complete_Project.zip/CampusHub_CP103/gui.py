"""Tkinter user interface for CampusHub."""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import date
from database import Database
from services import CampusHubService
from reports import export_inventory

class CampusHubApp:
    def __init__(self, root):
        self.root = root
        self.root.title("CampusHub | School Resource Borrowing and Inventory")
        self.root.geometry("1120x720")
        self.root.minsize(950, 620)
        self.db = Database()
        self.service = CampusHubService(self.db)
        self.selected_asset = None
        self._style()
        self._build()
        self.refresh_all()

    def _style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Treeview", rowheight=25)
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"))
        style.configure("Section.TLabel", font=("Segoe UI", 11, "bold"))

    def _build(self):
        header = ttk.Frame(self.root, padding=12)
        header.pack(fill="x")
        ttk.Label(header, text="CampusHub", style="Title.TLabel").pack(side="left")
        ttk.Label(header, text="School Resource Borrowing & Inventory Management",
                  foreground="#555").pack(side="left", padx=16, pady=(8,0))

        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(fill="both", expand=True, padx=12, pady=(0,12))
        self.inventory_tab = ttk.Frame(self.tabs, padding=10)
        self.borrower_tab = ttk.Frame(self.tabs, padding=10)
        self.checkout_tab = ttk.Frame(self.tabs, padding=10)
        self.return_tab = ttk.Frame(self.tabs, padding=10)
        self.monitor_tab = ttk.Frame(self.tabs, padding=10)
        for frame, label in [(self.inventory_tab,"Inventory"),(self.borrower_tab,"Borrowers"),
                             (self.checkout_tab,"Checkout"),(self.return_tab,"Returns"),
                             (self.monitor_tab,"Monitoring")]:
            self.tabs.add(frame, text=label)
        self._inventory_ui()
        self._borrower_ui()
        self._checkout_ui()
        self._return_ui()
        self._monitor_ui()

    def _tree(self, parent, columns, headings, height=11):
        wrap = ttk.Frame(parent)
        wrap.pack(fill="both", expand=True, pady=8)
        tree = ttk.Treeview(wrap, columns=columns, show="headings", height=height)
        ybar = ttk.Scrollbar(wrap, orient="vertical", command=tree.yview)
        xbar = ttk.Scrollbar(wrap, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        for col, heading in zip(columns, headings):
            tree.heading(col, text=heading)
            tree.column(col, width=130, anchor="w")
        tree.grid(row=0,column=0,sticky="nsew")
        ybar.grid(row=0,column=1,sticky="ns")
        xbar.grid(row=1,column=0,sticky="ew")
        wrap.rowconfigure(0,weight=1); wrap.columnconfigure(0,weight=1)
        return tree

    def _inventory_ui(self):
        form = ttk.LabelFrame(self.inventory_tab, text="Equipment details", padding=10)
        form.pack(fill="x")
        self.asset_vars = {k: tk.StringVar() for k in
            ("asset_code","name","category","location","condition")}
        labels = [("asset_code","Asset code"),("name","Name"),("category","Category"),
                  ("location","Location"),("condition","Condition")]
        for i,(key,label) in enumerate(labels):
            ttk.Label(form,text=label).grid(row=i//3*2,column=i%3,padx=5,pady=(2,0),sticky="w")
            ttk.Entry(form,textvariable=self.asset_vars[key],width=27).grid(
                row=i//3*2+1,column=i%3,padx=5,pady=(0,5),sticky="ew")
        ttk.Button(form,text="Add asset",command=self.add_asset).grid(row=0,column=3,padx=5)
        ttk.Button(form,text="Update selected",command=self.update_asset).grid(row=1,column=3,padx=5)
        ttk.Button(form,text="Deactivate selected",command=self.deactivate_asset).grid(row=2,column=3,padx=5)
        ttk.Button(form,text="Clear form",command=self.clear_asset_form).grid(row=3,column=3,padx=5)
        for c in range(3): form.columnconfigure(c,weight=1)
        searchbar=ttk.Frame(self.inventory_tab); searchbar.pack(fill="x",pady=5)
        ttk.Label(searchbar,text="Search code, name, or category:").pack(side="left")
        self.asset_search=tk.StringVar()
        ttk.Entry(searchbar,textvariable=self.asset_search,width=30).pack(side="left",padx=6)
        ttk.Button(searchbar,text="Search",command=self.refresh_inventory).pack(side="left")
        ttk.Button(searchbar,text="Show all",command=lambda:self.asset_search.set("") or self.refresh_inventory()).pack(side="left",padx=5)
        ttk.Button(searchbar,text="Export CSV",command=self.export_assets).pack(side="right")
        self.asset_tree=self._tree(self.inventory_tab,
            ("asset_id","asset_code","name","category","location","condition","status"),
            ("ID","Asset code","Name","Category","Location","Condition","Status"))
        self.asset_tree.bind("<<TreeviewSelect>>",self.select_asset)

    def _borrower_ui(self):
        form=ttk.LabelFrame(self.borrower_tab,text="Register borrower",padding=10); form.pack(fill="x")
        self.borrower_vars={k:tk.StringVar() for k in ("borrower_code","display_name","department_or_program")}
        for i,(key,label) in enumerate([("borrower_code","Borrower code"),("display_name","Full name"),("department_or_program","Department / program")]):
            ttk.Label(form,text=label).grid(row=0,column=i,sticky="w",padx=5)
            ttk.Entry(form,textvariable=self.borrower_vars[key],width=30).grid(row=1,column=i,padx=5,pady=5,sticky="ew")
            form.columnconfigure(i,weight=1)
        ttk.Button(form,text="Add borrower",command=self.add_borrower).grid(row=1,column=3,padx=8)
        bar=ttk.Frame(self.borrower_tab); bar.pack(fill="x",pady=6)
        ttk.Label(bar,text="Search borrower:").pack(side="left")
        self.borrower_search=tk.StringVar()
        ttk.Entry(bar,textvariable=self.borrower_search,width=32).pack(side="left",padx=6)
        ttk.Button(bar,text="Search",command=self.refresh_borrowers).pack(side="left")
        ttk.Button(bar,text="Show all",command=lambda:self.borrower_search.set("") or self.refresh_borrowers()).pack(side="left",padx=5)
        self.borrower_tree=self._tree(self.borrower_tab,
            ("borrower_id","borrower_code","display_name","department_or_program","active"),
            ("ID","Borrower code","Name","Department / program","Active"))

    def _checkout_ui(self):
        form=ttk.LabelFrame(self.checkout_tab,text="New equipment checkout",padding=14); form.pack(fill="x",anchor="n")
        self.checkout_vars={k:tk.StringVar() for k in ("asset_code","borrower_code","borrowed_on","due_on")}
        self.checkout_vars["borrowed_on"].set(date.today().isoformat())
        self.checkout_vars["due_on"].set(date.today().isoformat())
        fields=[("asset_code","Available asset code"),("borrower_code","Borrower code"),
                ("borrowed_on","Borrow date (YYYY-MM-DD)"),("due_on","Due date (YYYY-MM-DD)")]
        for i,(key,label) in enumerate(fields):
            ttk.Label(form,text=label).grid(row=i//2*2,column=i%2,sticky="w",padx=8,pady=(5,0))
            ttk.Entry(form,textvariable=self.checkout_vars[key],width=34).grid(
                row=i//2*2+1,column=i%2,sticky="ew",padx=8,pady=5)
        ttk.Button(form,text="Save checkout",command=self.checkout).grid(row=4,column=0,pady=12,sticky="w",padx=8)
        ttk.Label(form,text="The asset must be Available and the borrower must be active.",
                  foreground="#555").grid(row=4,column=1,sticky="w")
        form.columnconfigure(0,weight=1);form.columnconfigure(1,weight=1)

    def _return_ui(self):
        form=ttk.LabelFrame(self.return_tab,text="Process equipment return",padding=14); form.pack(fill="x",anchor="n")
        self.return_id=tk.StringVar()
        self.return_date=tk.StringVar(value=date.today().isoformat())
        ttk.Label(form,text="Active loan ID").grid(row=0,column=0,sticky="w",padx=5)
        ttk.Entry(form,textvariable=self.return_id,width=25).grid(row=1,column=0,padx=5,pady=5)
        ttk.Label(form,text="Return date (YYYY-MM-DD)").grid(row=0,column=1,sticky="w",padx=5)
        ttk.Entry(form,textvariable=self.return_date,width=25).grid(row=1,column=1,padx=5,pady=5)
        ttk.Button(form,text="Process return",command=self.process_return).grid(row=1,column=2,padx=10)
        ttk.Label(form,text="Select a loan ID from the Active Loans table below.",
                  foreground="#555").grid(row=2,column=0,columnspan=3,sticky="w",padx=5,pady=8)
        self.return_tree=self._tree(self.return_tab,
            ("loan_id","asset_code","asset_name","borrower_code","borrower_name","borrowed_on","due_on","display_status"),
            ("Loan ID","Asset code","Equipment","Borrower code","Borrower","Borrowed","Due","Status"),height=12)
        self.return_tree.bind("<<TreeviewSelect>>",self.select_loan)

    def _monitor_ui(self):
        self.count_frame=ttk.Frame(self.monitor_tab); self.count_frame.pack(fill="x",pady=5)
        self.count_labels={}
        for key,label in [("total_assets","Total assets"),("available_assets","Available assets"),
                          ("active_loans","Active loans"),("overdue_loans","Overdue loans")]:
            card=ttk.LabelFrame(self.count_frame,text=label,padding=12)
            card.pack(side="left",fill="x",expand=True,padx=5)
            value=ttk.Label(card,text="0",font=("Segoe UI",20,"bold"))
            value.pack()
            self.count_labels[key]=value
        bar=ttk.Frame(self.monitor_tab);bar.pack(fill="x",pady=6)
        ttk.Label(bar,text="Loan view:").pack(side="left")
        self.loan_view=tk.StringVar(value="active")
        self.loan_filter=ttk.Combobox(bar,textvariable=self.loan_view,state="readonly",
            values=("active","overdue","returned","all"),width=14)
        self.loan_filter.pack(side="left",padx=5)
        self.loan_filter.bind("<<ComboboxSelected>>",lambda e:self.refresh_monitor())
        ttk.Label(bar,text="Search:").pack(side="left",padx=(15,0))
        self.loan_search=tk.StringVar()
        ttk.Entry(bar,textvariable=self.loan_search,width=28).pack(side="left",padx=5)
        ttk.Button(bar,text="Apply",command=self.refresh_monitor).pack(side="left")
        self.monitor_tree=self._tree(self.monitor_tab,
            ("loan_id","asset_code","asset_name","borrower_code","borrower_name","borrowed_on","due_on","returned_on","display_status"),
            ("Loan ID","Asset code","Equipment","Borrower code","Borrower","Borrowed","Due","Returned","Status"),height=13)

    def _message(self, operation):
        try:
            operation()
        except (ValueError, sqlite3.Error) as exc:
            messagebox.showerror("CampusHub",str(exc))
            return False
        except Exception as exc:
            messagebox.showerror("Unexpected error",f"An unexpected error occurred:\n{exc}")
            return False
        return True

    def add_asset(self):
        values={k:v.get() for k,v in self.asset_vars.items()}
        if self._message(lambda:self.service.add_equipment(values)):
            messagebox.showinfo("Success","Equipment added successfully.")
            self.clear_asset_form();self.refresh_all()

    def update_asset(self):
        if not self.selected_asset:
            messagebox.showwarning("Select asset","Select an inventory row first.");return
        row=self.db.get_equipment(self.selected_asset[1])
        if row is None:return
        values={k:self.asset_vars[k].get() for k in ("name","category","location","condition")}
        values["status"]=row["status"]
        if row["status"] not in ("Borrowed","Inactive"):
            values["status"]="Under Maintenance" if values["condition"].lower()=="under maintenance" else row["status"]
        if self._message(lambda:self.service.update_equipment(row["asset_id"],values,row["status"])):
            messagebox.showinfo("Success","Equipment details updated.")
            self.refresh_all()

    def deactivate_asset(self):
        if not self.selected_asset:
            messagebox.showwarning("Select asset","Select an inventory row first.");return
        if not messagebox.askyesno("Confirm","Mark this equipment as Inactive? The record will be retained."):return
        if self._message(lambda:self.db.deactivate_equipment(self.selected_asset[0])):
            messagebox.showinfo("Success","Equipment marked inactive.")
            self.clear_asset_form();self.refresh_all()

    def select_asset(self,event=None):
        selected=self.asset_tree.selection()
        if not selected:return
        values=self.asset_tree.item(selected[0],"values")
        self.selected_asset=(int(values[0]),values[1])
        for key,val in zip(("asset_code","name","category","location","condition"),values[1:6]):
            self.asset_vars[key].set(val)

    def clear_asset_form(self):
        self.selected_asset=None
        for var in self.asset_vars.values():var.set("")

    def add_borrower(self):
        values={k:v.get() for k,v in self.borrower_vars.items()}
        if self._message(lambda:self.service.add_borrower(values)):
            messagebox.showinfo("Success","Borrower registered successfully.")
            for var in self.borrower_vars.values():var.set("")
            self.refresh_borrowers()

    def checkout(self):
        v={k:x.get().strip() for k,x in self.checkout_vars.items()}
        if self._message(lambda:self.service.checkout(v["asset_code"],v["borrower_code"],v["borrowed_on"],v["due_on"])):
            messagebox.showinfo("Success","Checkout saved. The equipment is now marked Borrowed.")
            self.refresh_all()

    def select_loan(self,event=None):
        selected=self.return_tree.selection()
        if selected:self.return_id.set(self.return_tree.item(selected[0],"values")[0])

    def process_return(self):
        try: loan_id=int(self.return_id.get().strip())
        except ValueError:
            messagebox.showerror("Invalid loan ID","Enter or select a valid numeric loan ID.");return
        if self._message(lambda:self.service.return_item(loan_id,self.return_date.get().strip())):
            messagebox.showinfo("Success","Return recorded. Equipment is Available again.")
            self.refresh_all()

    def export_assets(self):
        path=filedialog.asksaveasfilename(defaultextension=".csv",
            filetypes=[("CSV files","*.csv")],title="Export inventory")
        if not path:return
        rows=self.db.list_equipment(self.asset_search.get())
        if self._message(lambda:export_inventory(rows,path)):
            messagebox.showinfo("Export complete",f"Inventory exported to:\n{path}")

    def _fill_tree(self,tree,rows,keys):
        tree.delete(*tree.get_children())
        for row in rows:  # Loop: render each database record in the table.
            tree.insert("","end",values=tuple(row[k] for k in keys))

    def refresh_inventory(self):
        self._fill_tree(self.asset_tree,self.db.list_equipment(self.asset_search.get()),
            ("asset_id","asset_code","name","category","location","condition","status"))

    def refresh_borrowers(self):
        self._fill_tree(self.borrower_tree,self.db.list_borrowers(self.borrower_search.get()),
            ("borrower_id","borrower_code","display_name","department_or_program","active"))

    def refresh_monitor(self):
        rows=self.db.list_loans(self.loan_view.get(),self.loan_search.get())
        self._fill_tree(self.monitor_tree,rows,("loan_id","asset_code","asset_name","borrower_code",
            "borrower_name","borrowed_on","due_on","returned_on","display_status"))

    def refresh_returns(self):
        self._fill_tree(self.return_tree,self.db.list_loans("active"),
            ("loan_id","asset_code","asset_name","borrower_code","borrower_name",
             "borrowed_on","due_on","display_status"))

    def refresh_all(self):
        # match-case is used in service.dispatch() for real application navigation/data selection.
        self.refresh_inventory();self.refresh_borrowers();self.refresh_returns();self.refresh_monitor()
        counts=self.db.dashboard_counts()
        for key,value in counts.items():self.count_labels[key].configure(text=str(value))

def run_app():
    root=tk.Tk()
    CampusHubApp(root)
    root.mainloop()
