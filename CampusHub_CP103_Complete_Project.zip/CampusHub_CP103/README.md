# CampusHub – CP 103 Python Programming Project

**School Resource Borrowing and Inventory Management System**

## Requirements
- Python 3.10 or newer (the project uses `match-case` and modern type hints).
- Tkinter (included with most standard Python installations).
- SQLite (included in Python's standard library).
- No third-party packages are required.

## Run the application
1. Extract the `CampusHub_CP103` folder.
2. Open a terminal/Command Prompt in that folder.
3. Run `python main.py` (Windows may use `py main.py`).
4. The `data/campushub.db` SQLite database is created automatically on first launch.

## Main workflow
1. Add equipment in **Inventory**. Asset codes must be unique.
2. Add borrowers in **Borrowers**. Borrower codes must be unique.
3. Enter the asset code, borrower code, borrow date and due date in **Checkout**.
4. Select an active loan in **Returns** and process its return.
5. Use **Monitoring** to filter active, overdue, returned or all loans.
6. Export the inventory table to CSV using the Export CSV button.

## Data and safety rules
- Equipment with transaction history is marked Inactive rather than deleted.
- A borrowed asset cannot be checked out again.
- Only active borrowers may borrow equipment.
- Due dates cannot be earlier than borrow dates.
- Return dates cannot be earlier than borrow dates or later than today.
- SQL statements use placeholders (`?`) rather than string concatenation.
- SQLite foreign-key enforcement is enabled for every connection.
- Loan status is stored as Active/Returned; overdue is calculated from today's date and the due date.

## Project modules
- `main.py`: entry point.
- `gui.py`: Tkinter screens, controls and event handlers.
- `database.py`: schema, SQL and persistence.
- `models.py`: Equipment, Borrower and Loan dataclasses.
- `services.py`: application rules and match-case dispatcher.
- `validators.py`: required-field and date validation.
- `reports.py`: CSV export.
- `data/`: generated database.

## Troubleshooting
- **Tkinter not found:** install a Python distribution that includes Tcl/Tk. On some Linux distributions, install the OS package `python3-tk`.
- **Window does not appear:** run the command from a desktop session, not a headless terminal.
- **Database appears locked:** close other CampusHub instances and try again.
- **Reset test data:** close the app, back up `data/campushub.db`, then delete that file. A new empty database is created next launch. This permanently removes local test records.
- **CSV export:** choose a writable folder and keep the `.csv` extension.

## Demo records
Use fictional records only, unless your instructor provides approved test records. Example:
- Asset: `AS-001`, Dell Laptop, Laptop, Computer Laboratory, Good.
- Borrower: `STU-001`, Alex Sample, Computer Technology.
These are examples only; they are not preloaded.

## Academic integrity note
Review and understand the code before presenting it. Adapt the title page and author details, run the test plan on your own computer, capture genuine screenshots, and follow your instructor's policy for acknowledging AI assistance.
