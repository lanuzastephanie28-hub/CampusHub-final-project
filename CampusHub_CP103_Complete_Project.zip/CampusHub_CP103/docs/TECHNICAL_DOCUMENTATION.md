# CampusHub
## Technical Documentation
**Course:** CP 103 – Python Programming  
**Project:** School Resource Borrowing and Inventory Management System  
**Prepared by:** [Insert student name(s)]  
**Section:** [Insert section]  
**Instructor:** [Insert instructor]  
**Submission date:** [Insert date]

---

# 1. Introduction, Problem Statement and Rationale

Schools and computer laboratories maintain shared resources such as laptops, projectors, networking devices and cables. When records are handled only through notebooks or separate spreadsheets, staff may find it difficult to locate equipment, check availability, monitor due dates and preserve borrowing history.

CampusHub is a local desktop application intended to organize these activities in one place. It uses Python, Tkinter and SQLite. The application provides inventory records, borrower records, equipment checkout and return processing, and loan monitoring.

## 1.1 Intended users
The intended users are a laboratory custodian, faculty member, department staff member or an authorized student assistant. The project uses a simple user model. Authentication and role-based permissions are outside the minimum scope.

## 1.2 General objective
To develop a working desktop application that manages school equipment inventory and the borrowing workflow while preserving records in a local SQLite database.

## 1.3 Specific objectives
1. Add, list, search, update and deactivate equipment records.
2. Register and search borrowers using unique borrower codes.
3. Record checkout transactions with borrow and due dates.
4. Process valid returns and restore equipment availability.
5. Monitor available equipment, active loans and overdue loans.
6. Validate essential fields, duplicate codes, equipment availability and dates.
7. Preserve records after the application is closed and reopened.

# 2. Scope, Boundaries and Assumptions

CampusHub is designed for one local computer and one local SQLite database file. It does not require online hosting, cloud storage, payment processing, a complex login system or integration with the school's information system.

Assumptions:
- Users enter accurate equipment and borrower details.
- Borrower and asset codes are unique identifiers.
- The computer's system date is correct.
- Only authorized staff or assistants operate the local application.
- Test records are fictional or approved by the instructor.

Limitations:
- There is no multi-user network synchronization.
- There is no authentication or permission management.
- Borrowers are not physically verified by the software.
- The application does not send automatic email or SMS reminders.
- The app records a return date but does not currently provide a detailed damage-condition workflow.

# 3. Functional and Non-Functional Requirements

## 3.1 Functional requirements
| ID | Requirement |
|---|---|
| FR-01 | Add equipment with a unique asset code. |
| FR-02 | Display and search equipment by code, name or category. |
| FR-03 | Update equipment details. |
| FR-04 | Mark equipment Inactive instead of deleting historical records. |
| FR-05 | Register and search borrowers using a unique borrower code. |
| FR-06 | Check out an available asset to an active borrower. |
| FR-07 | Save borrow and due dates. |
| FR-08 | Return an active loan and make its equipment Available. |
| FR-09 | Display available assets, active loans and overdue loans. |
| FR-10 | Export the inventory list to CSV. |
| FR-11 | Retain records in SQLite after closing the program. |

## 3.2 Non-functional requirements
- **Usability:** labels, tabs, tables and feedback messages should be understandable.
- **Reliability:** invalid actions should be blocked and reported.
- **Data integrity:** primary keys, unique constraints and foreign keys protect related records.
- **Maintainability:** interface, data access, validation and business logic are separated into modules.
- **Portability:** the program uses Python standard-library modules.

# 4. System Architecture and Module Design

CampusHub follows a simple layered structure:

| Module | Responsibility |
|---|---|
| `main.py` | Starts the application. |
| `gui.py` | Creates Tkinter tabs, forms, tables and event handlers. |
| `services.py` | Applies checkout, return and validation rules. |
| `database.py` | Creates tables and executes parameterized SQL operations. |
| `models.py` | Defines Equipment, Borrower and Loan data classes. |
| `validators.py` | Checks required fields and date rules. |
| `reports.py` | Exports inventory records to CSV. |

The GUI calls service methods. The service layer checks business rules before asking the database layer to save changes. This separation makes the program easier to test and maintain.

## 4.1 System flowchart

```mermaid
flowchart TD
 A([Start]) --> B[Open CampusHub]
 B --> C[Initialize or connect to SQLite]
 C --> D[Display main tabs]
 D --> E{User action}
 E -->|Inventory| F[Add, search, update or deactivate asset]
 E -->|Borrowers| G[Register or search borrower]
 E -->|Checkout| H[Validate asset, borrower and dates]
 H --> I{Valid and available?}
 I -->|No| J[Show error message]
 I -->|Yes| K[Save loan and mark asset Borrowed]
 E -->|Return| L[Find active loan and validate return date]
 L --> M{Valid active loan?}
 M -->|No| J
 M -->|Yes| N[Save return and mark asset Available]
 E -->|Monitoring| O[Show counts and filtered loan records]
 J --> D
 F --> D
 G --> D
 K --> D
 N --> D
 O --> D
 D --> P{Exit?}
 P -->|No| E
 P -->|Yes| Q([Close application])
```

## 4.2 Class descriptions
- **Equipment:** represents an asset with asset code, name, category, location, condition and status.
- **Borrower:** represents a borrower with borrower code, display name, department/program and active flag.
- **Loan:** represents a borrowing transaction with loan ID, asset, borrower, dates and status.
- **Database:** manages SQLite connections, schema creation and data operations.
- **CampusHubService:** enforces application rules and coordinates operations.
- **CampusHubApp:** manages the graphical interface and user interaction.

# 5. Database Design

SQLite is used through Python's built-in `sqlite3` module. The database file is created automatically at `data/campushub.db`.

## 5.1 Entity-relationship diagram

```mermaid
erDiagram
 EQUIPMENT ||--o{ LOANS : "has transactions"
 BORROWERS ||--o{ LOANS : "makes"
 EQUIPMENT {
  INTEGER asset_id PK
  TEXT asset_code UK
  TEXT name
  TEXT category
  TEXT location
  TEXT condition
  TEXT status
 }
 BORROWERS {
  INTEGER borrower_id PK
  TEXT borrower_code UK
  TEXT display_name
  TEXT department_or_program
  INTEGER active
 }
 LOANS {
  INTEGER loan_id PK
  INTEGER asset_id FK
  INTEGER borrower_id FK
  TEXT borrowed_on
  TEXT due_on
  TEXT returned_on
  TEXT status
 }
```

One equipment record may have multiple loan-history records over time. One borrower may also have multiple loan records. Each loan refers to one equipment record and one borrower.

## 5.2 Tables and constraints

### equipment
| Field | Type | Rule / meaning |
|---|---|---|
| asset_id | INTEGER | Primary key, auto-increment |
| asset_code | TEXT | Required, unique |
| name | TEXT | Required |
| category | TEXT | Required |
| location | TEXT | Required |
| condition | TEXT | Required; default Good |
| status | TEXT | Available, Borrowed, Under Maintenance or Inactive |

### borrowers
| Field | Type | Rule / meaning |
|---|---|---|
| borrower_id | INTEGER | Primary key, auto-increment |
| borrower_code | TEXT | Required, unique |
| display_name | TEXT | Required |
| department_or_program | TEXT | Required |
| active | INTEGER | 1 = active; 0 = inactive |

### loans
| Field | Type | Rule / meaning |
|---|---|---|
| loan_id | INTEGER | Primary key, auto-increment |
| asset_id | INTEGER | Foreign key to equipment |
| borrower_id | INTEGER | Foreign key to borrowers |
| borrowed_on | TEXT | ISO date YYYY-MM-DD |
| due_on | TEXT | ISO date YYYY-MM-DD |
| returned_on | TEXT | Blank until returned |
| status | TEXT | Active or Returned |

Unique constraints prevent duplicate asset and borrower codes. Foreign keys ensure that each loan refers to existing equipment and borrower records. The application enables SQLite foreign-key enforcement on each connection.

## 5.3 Data dictionary notes
- `Available`: equipment can be checked out.
- `Borrowed`: equipment has an active loan.
- `Under Maintenance`: equipment is not available for checkout.
- `Inactive`: equipment is retained in the database but excluded from active inventory totals.
- `Active`: loan has not been returned.
- `Returned`: return has been recorded.
- `Overdue`: a calculated display status for an Active loan whose due date is before the current date. It is not stored as a separate loan status.

# 6. Algorithms and Business Rules

## 6.1 Checkout algorithm
1. Receive asset code, borrower code, borrow date and due date.
2. Check that all fields are present.
3. Parse both dates using the ISO date format.
4. Reject a future borrow date.
5. Reject a due date earlier than the borrow date.
6. Search for the asset and borrower.
7. Reject missing records.
8. Reject an asset that is not Available.
9. Reject an inactive borrower.
10. Insert an Active loan using parameterized SQL.
11. Update the equipment status to Borrowed.
12. Commit the transaction and refresh the displayed records.

Pseudocode:

```text
INPUT asset_code, borrower_code, borrowed_on, due_on
IF required data is missing THEN show error
ELSE IF dates are invalid THEN show error
ELSE find asset and borrower
    IF either record is missing THEN show error
    ELSE IF asset is not Available THEN show error
    ELSE IF borrower is inactive THEN show error
    ELSE save loan and set asset to Borrowed
         show success
```

## 6.2 Return algorithm
1. Receive a loan ID and return date.
2. Confirm that the loan exists.
3. Confirm that its status is Active.
4. Validate the return date.
5. Reject a return date earlier than the borrow date or later than today.
6. Save the return date and change the loan status to Returned.
7. Change the associated equipment status to Available.
8. Refresh the tables and dashboard.

## 6.3 Validation and error handling
The application uses:
- Required-field checks.
- Unique database constraints for asset and borrower codes.
- Status checks before checkout.
- ISO date parsing and chronological checks.
- Parameterized SQL queries.
- `try/except` handling for validation and database errors.
- Confirmation before deactivating equipment.

## 6.4 Required Python concepts
| Concept | Implementation |
|---|---|
| if–elif–else | Business-rule and validation decisions in the service/database layers. |
| Loops | Iterating through database records to populate Tkinter tables. |
| match–case | `CampusHubService.dispatch()` routes inventory, borrower, active-loan and overdue actions, with a default case. |
| Functions | Methods for adding records, checkout, return, search, refresh and export. |
| Classes | Equipment, Borrower, Loan, Database, CampusHubService and CampusHubApp. |
| Modules | Separate `.py` files with clear responsibilities. |
| Tkinter | Notebook tabs, forms, buttons, dialogs, Treeview tables and scrollbars. |

# 7. Testing Plan

Run each test on the actual computer where the project will be demonstrated. Record the actual outcome after testing; do not mark a test Passed until it has been performed.

| Test | Action / input | Expected result | Actual result | Status |
|---|---|---|---|---|
| T1 | Add a new asset code | Saved and shown in inventory | To be recorded | Pending |
| T2 | Add the same asset code again | Duplicate rejected | To be recorded | Pending |
| T3 | Submit equipment with blank required field | Save blocked with message | To be recorded | Pending |
| T4 | Checkout available asset to active borrower with valid dates | Loan saved; asset becomes Borrowed | To be recorded | Pending |
| T5 | Checkout the same asset again | Second checkout blocked | To be recorded | Pending |
| T6 | Due date earlier than borrow date | Validation blocks checkout | To be recorded | Pending |
| T7 | Return an active loan with valid date | Loan becomes Returned; asset Available | To be recorded | Pending |
| T8 | View overdue loans with an overdue test record | Overdue loan appears | To be recorded | Pending |
| T9 | Close and relaunch application | Saved records remain | To be recorded | Pending |
| T10 | Search nonexistent asset code | Empty table; app remains responsive | To be recorded | Pending |
| T11 | Return the same loan a second time | Duplicate return rejected | To be recorded | Pending |
| T12 | Enter malformed date | Clear validation message | To be recorded | Pending |

## 7.1 Negative tests
T2, T3, T5, T6, T11 and T12 are negative tests. They verify that the application rejects invalid or unsafe actions without corrupting records.

# 8. Installation and User Guide

## 8.1 Prerequisites
- Python 3.10 or newer.
- Tkinter installed.
- A desktop environment capable of opening a GUI window.
- No external Python packages are required.

## 8.2 Installation
1. Extract the project ZIP file.
2. Open the extracted `CampusHub_CP103` folder.
3. Open Command Prompt or a terminal in that folder.
4. Run `python main.py` or, on Windows, `py main.py`.
5. The application creates the database automatically.

## 8.3 Using the application
### Inventory
Enter asset code, name, category, location and condition, then click Add asset. Select a row to load its details. Update selected changes editable details. Deactivate selected retains the record but marks it Inactive.

### Borrowers
Enter a unique borrower code, full name and department/program. Click Add borrower. Search by code, name or department/program.

### Checkout
Enter an available asset code, active borrower code, borrow date and due date in YYYY-MM-DD format. Click Save checkout. A successful checkout changes the equipment status to Borrowed.

### Returns
Select an active loan in the table. Its loan ID is placed in the Loan ID field. Enter a valid return date and click Process return.

### Monitoring
View dashboard totals and select Active, Overdue, Returned or All. Search by asset or borrower details. The overdue status is calculated from the due date.

### CSV export
In Inventory, click Export CSV and select a destination. The file can be opened in spreadsheet software.

## 8.4 Backup and reset
To back up records, close the application and copy `data/campushub.db` to a safe location. To reset the test database, close the application, back up the file if needed, and delete it. The next launch creates a new empty database. Resetting deletes local records.

## 8.5 Screenshot evidence to capture
Capture genuine screenshots after running the app:
1. Main Inventory tab with sample equipment.
2. Borrowers tab with fictional borrower records.
3. Checkout form and successful checkout result.
4. Returns tab showing an active loan.
5. Monitoring dashboard showing counts and loan statuses.
6. A validation message, such as a duplicate-code rejection.

Insert each screenshot in the final submitted document with a figure number and short caption. Do not use mock screenshots as proof of actual testing.

## 8.6 Troubleshooting
- If Tkinter cannot be imported, install a Python distribution that includes Tcl/Tk. On some Linux systems, install `python3-tk`.
- If the window does not appear, run the program in a desktop session.
- If the database is locked, close other running copies of CampusHub.
- If CSV export fails, select a folder where the user has write permission.

# 9. Conclusion

CampusHub provides a local desktop solution for recording school equipment, borrowers and borrowing transactions. Its Tkinter interface supports the main workflow, while SQLite preserves records and enforces relationships. Validation and status checks help prevent duplicate codes, invalid dates and checkout of unavailable equipment. The modular design demonstrates the Python concepts specified in the CP 103 project guide.

# 10. References and Attribution

1. Cabuyaban, R. M. (2026–2027). *CP 103 – Python Programming: Midterm & Final Project Guide*. Course assessment guide supplied for this project.
2. Python Software Foundation. *Python Documentation*. https://docs.python.org/3/
3. Python Software Foundation. *tkinter — Python interface to Tcl/Tk*. https://docs.python.org/3/library/tkinter.html
4. Python Software Foundation. *sqlite3 — DB-API 2.0 interface for SQLite databases*. https://docs.python.org/3/library/sqlite3.html

**AI assistance disclosure:** This project draft was prepared with AI assistance. The student should review, understand, test, adapt and disclose assistance according to the instructor's academic-integrity policy.
