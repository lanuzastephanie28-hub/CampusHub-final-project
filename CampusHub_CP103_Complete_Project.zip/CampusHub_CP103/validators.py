"""Input and date validation helpers."""
from datetime import date

def required_fields(values: dict) -> tuple[bool, str]:
    for label, value in values.items():
        if not str(value).strip():
            return False, f"{label} is required."
    return True, ""

def valid_code(code: str) -> bool:
    return bool(code.strip()) and len(code.strip()) <= 30

def validate_loan_dates(borrowed_on: str, due_on: str) -> tuple[bool, str]:
    try:
        borrowed = date.fromisoformat(borrowed_on)
        due = date.fromisoformat(due_on)
    except ValueError:
        return False, "Enter dates in YYYY-MM-DD format."
    if borrowed > date.today():
        return False, "Borrow date cannot be in the future."
    if due < borrowed:
        return False, "Due date cannot be earlier than the borrow date."
    return True, ""

def validate_return_date(returned_on: str, borrowed_on: str) -> tuple[bool, str]:
    try:
        returned = date.fromisoformat(returned_on)
        borrowed = date.fromisoformat(borrowed_on)
    except ValueError:
        return False, "Enter the return date in YYYY-MM-DD format."
    if returned < borrowed:
        return False, "Return date cannot be earlier than the borrow date."
    if returned > date.today():
        return False, "Return date cannot be in the future."
    return True, ""
