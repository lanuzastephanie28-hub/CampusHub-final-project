"""Reporting helpers."""
import csv
from pathlib import Path

def export_inventory(rows, destination):
    """Export visible inventory rows to a CSV file."""
    fields = ["asset_code", "name", "category", "location", "condition", "status"]
    with Path(destination).open("w", newline="", encoding="utf-8-sig") as output:
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row[field] for field in fields})
