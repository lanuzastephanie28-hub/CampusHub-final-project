"""Domain models used by CampusHub."""
from dataclasses import dataclass

@dataclass
class Equipment:
    asset_code: str
    name: str
    category: str
    location: str
    condition: str = "Good"
    status: str = "Available"

@dataclass
class Borrower:
    borrower_code: str
    display_name: str
    department_or_program: str
    active: bool = True

@dataclass
class Loan:
    loan_id: int
    asset_code: str
    asset_name: str
    borrower_code: str
    borrower_name: str
    borrowed_on: str
    due_on: str
    returned_on: str | None
    status: str
